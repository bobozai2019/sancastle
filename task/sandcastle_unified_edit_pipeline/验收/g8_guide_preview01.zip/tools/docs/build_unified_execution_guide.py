"""Build the current offline guide from exact unified source anchors."""
import argparse
import hashlib
import html
import json
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[2]
OUTPUT=ROOT/'docs/project-execution-guide.html'
INDEX=ROOT/'docs/project-execution-guide.sources.json'
BASE='scripts/simulation/unified_edit/'
ANCHORS=[('入口','scripts/beach/unified_playable_entry.gd','_ready'),
         ('声明',BASE+'player_input.gd','begin'),('注册表',BASE+'profile_registry.gd','resolve'),
         ('冻结配置',BASE+'configuration.gd','freeze'),('主调度',BASE+'pipeline.gd','pump'),
         ('唯一录制',BASE+'pipeline.gd','_submit_render'),('编辑骨架',BASE+'executor.gd','record'),
         ('公共水响应',BASE+'water_response.gd','record'),('水条件提交',BASE+'water_response.gd','commit'),
         ('水tick',BASE+'water.gd','record_tick'),('初始化与native资源',BASE+'state.gd','initialize'),
         ('碰撞消费',BASE+'height.gd','physics_consume'),('换代提交',BASE+'domain_runtime.gd','_physics_process'),
         ('恢复工厂',BASE+'domain_runtime.gd','restore_checkpoint'),('原生校验',BASE+'checkpoint_codec.gd','validate'),
         ('存档路由',BASE+'checkpoint_router.gd','load_file'),('正式切换','scripts/beach/beach_scene_service.gd','_switch')]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def build():
    sources={};anchors=[]
    for title,path,symbol in ANCHORS:
        raw=(ROOT/path).read_bytes();text=raw.decode('utf-8-sig');match=re.search(r'^(?:static )?func '+re.escape(symbol)+r'\(',text,re.M)
        assert match is not None,path+'::'+symbol
        line=text[:match.start()].count('\n')+1;lines=text.splitlines();excerpt='\n'.join(f'{i+1:>4} {lines[i]}' for i in range(line-1,min(len(lines),line+9)))
        sources[path]=sha(raw);anchors.append({'title':title,'path':path,'symbol':symbol,'line':line,'sha256':sources[path],'excerpt':excerpt})
    for path in ['project.godot','scenes/main.tscn','scenes/playable/test1_capture.tscn','scenes/playable/test1_backwash.tscn','scenes/playable/test1_geometry.tscn','assets/unified_edit/default_catalog.tres','docs/unified-edit-extension-guide.md','tools/unified_edit_pipeline/architecture_policy.json','tools/docs/build_execution_guide.py','tools/docs/build_unified_execution_guide.py']:
        sources[path]=sha((ROOT/path).read_bytes())
    gate_path=ROOT/'task/sandcastle_unified_edit_pipeline/验收/G8_联合门.json'
    if not gate_path.exists():gate_path=ROOT/'task/sandcastle_unified_edit_pipeline/验收/G7_联合门.json'
    gate=json.loads(gate_path.read_text('utf-8'));sources[gate_path.relative_to(ROOT).as_posix()]=sha(gate_path.read_bytes())
    completed=gate['overall_completed'];total=gate['overall_total'];stage='G8' if gate.get('G8_pass') else 'G7'
    status=f'{completed}/{total} · {stage}已通过；'+('本轮交付见最终联合门。' if gate.get('G8_pass') else 'G8最终联合功能、长稳、成本与交付仍在验证。')
    cards=[]
    for anchor in anchors:
        cards.append('<details><summary>'+html.escape(anchor['title']+' · '+anchor['path']+':'+str(anchor['line']))+'</summary><p class="hash">SHA256 '+anchor['sha256']+'</p><pre>'+html.escape(anchor['excerpt'])+'</pre></details>')
    content='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sandcastle · 统一沙水执行指南</title>
<style>:root{font-family:system-ui,"Microsoft YaHei",sans-serif;color:#e9f1f4;background:#101d24;line-height:1.7}body{max-width:1040px;margin:auto;padding:40px 24px}a{color:#8bd6f7}h1{font-size:34px}h2{margin-top:38px;color:#f4d29b}h3{font-size:18px}.tag,.phase{display:inline-block;padding:7px 13px;margin:4px;border:1px solid #506879;border-radius:6px}.phase{background:#18333c}.commit{border-color:#edbc68;color:#ffe0a5}.muted{color:#adc0c8}.panel,details{background:#172a34;border:1px solid #304854;padding:18px;border-radius:10px;margin:14px 0}select{background:#243e48;color:white;padding:8px;border:1px solid #68828e;border-radius:5px;margin-right:12px}pre{overflow:auto;white-space:pre;font:13px/1.7 Consolas,monospace;background:#101b22;padding:16px}.hash{font:12px Consolas,monospace;overflow-wrap:anywhere}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:12px;border-bottom:1px solid #40525e}button{font:inherit}.flow{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.arrow{color:#87bec8}summary{cursor:pointer}code{color:#b7e6e5}@media(max-width:700px){body{padding:20px 14px}h1{font-size:26px}table{font-size:13px}}</style>
<p class="muted">本地源码生成 · 可离线查看 · 没有网络脚本或运行时写入</p><h1>同一个域，同一条沙水执行流程</h1><div class="panel">STATUS</div>
<p>四个正式场景由直接继承Node3D的统一入口加载。玩家工具只产生声明；域Runtime协调生命周期，Pipeline决定录制顺序，公共数值阶段完成候选、校验、条件提交与发布。</p>
<div class="flow"><span class="tag">场景 / 输入声明</span><span class="arrow">→</span><span class="tag">Runtime</span><span class="arrow">→</span><span class="tag">Pipeline 队列 / 3工作槽</span><span class="arrow">→</span><span class="tag">编辑 / 水tick / 显示</span><span class="arrow">→</span><span class="tag">同代完成态 / 2高度槽</span></div>
<h2>声明如何选择公共阶段</h2><p>下面只演示既有执行轨迹。选择操作和水策略会改变可见阶段标签，不执行Godot模拟。</p><div class="panel"><label>操作 <select id="operation"><option value="volume">体积增沙</option><option value="target">目标高度</option><option value="transfer">守恒搬运</option></select></label><label>水响应 <select id="water"><option value="0">0 · 关闭</option><option value="1">1 · 容量/位移</option><option value="2">2 · 速度路径</option><option value="3" selected>3 · 完整响应</option></select></label><p id="stroke"></p><div id="phases" class="flow"></div><p id="response"></p><p class="muted">阶段12为公共材料候选，5/6为校验，7为条件提交，8为结果；原语内部迭代不构成第二个事务。</p></div>
<h2>权威状态与读者边界</h2><table><tr><th>边界</th><th>实际职责</th></tr><tr><td>编辑执行器</td><td>只在公共决定允许时提交沙/材料等字段；拒绝保留原场。</td></tr><tr><td>水响应 / 水tick</td><td>前者共享编辑事务决定，后者拥有明确的水/侵蚀/材料子步；实际时钟由GPU完成态推进。</td></tr><tr><td>预览 / 表现 / 碰撞</td><td>读取同generation完整完成态。编辑无需等待CPU通知或碰撞收敛；消费者各自保留资源租约。</td></tr><tr><td>native保存 / 恢复</td><td>SANDUE06容器保留有效配置和原始资源字节。候选还是同一种Pipeline；完整64块新代物理槽准备后才切换。</td></tr><tr><td>关闭 / unknown</td><td>先关闭接纳，等待真实终结与最后读者证明。unknown不重放，不伪造GPU结果，不强制free未知所有权。</td></tr></table>
<h2>配置新增玩法</h2><p>新增ToolProfile资源，使用既有operation、shape、材料/水策略、数值范围和受限模板。注册表校验精确script类型并复制冻结数据；profile不得携带执行Callable、自选shader或调度器。</p><p>G7的宽填沙、阶梯模板和宽槽搬运通过23例GPU验证与全部已声明能力组合。核心51文件hash不变，三种配置在同一Runtime完成碰撞、原生恢复和继续编辑。完整步骤见<a href="unified-edit-extension-guide.md">扩展指南</a>。</p>
<h2>复验与证据</h2><p>当前验收入口：<a href="../task/sandcastle_unified_edit_pipeline/验收/README.md">任务验收索引</a>。功能、架构、阶段成本、整帧成本与长稳分别判定；导出日志成功不代替这些结论。失败与未知记录保留在原始输出目录。</p><p class="muted">旧HTML、来源索引和生成器的原字节保存在任务验收g8_previous_guide目录；旧任务和竞品报告不因本页更新而改写。</p>
<h2>当前源码锚点</h2><p class="muted">以下摘录、行号与SHA256直接来自生成时文件，可用build_execution_guide.py --check核对。</p>CARDS
<script>const op=document.getElementById('operation'),water=document.getElementById('water');function draw(){const base=[0,1,2,3];let v=op.value==='transfer'?base.concat([9,4,2,3,10,4,11,4]):base.concat([4]);v=v.concat([12,5,6,7,8]);document.getElementById('phases').replaceChildren(...v.map(n=>{let e=document.createElement('span');e.className='phase'+(n===7?' commit':'');e.textContent=String(n)+(n===7?' · 条件提交':'');return e}));document.getElementById('stroke').textContent=op.value==='volume'?'无固定笔画基准；按体积候选处理。':'公共BEGIN → sample序列 → END；固定基准与累计coverage由域持有。';document.getElementById('response').textContent=water.value==='0'?'水响应关闭，水/悬沙/动量不因该编辑被改写。':'公共水阶段：prepare → '+(water.value==='2'?'velocity_only':'packed')+' → displace → velocity → velocity_reduce → audit_blocks → audit_merge；与同一决定提交。'}op.addEventListener('change',draw);water.addEventListener('change',draw);draw();</script></html>'''
    content=content.replace('STATUS',html.escape(status)).replace('CARDS','\n'.join(cards))
    index={'schema':2,'family':'unified_edit','status':status,'sources':dict(sorted(sources.items())),'anchors':anchors,'limitations':'Documentation/source evidence only; execution, functional and cost verdicts belong to the linked gates.'}
    return content,json.dumps(index,ensure_ascii=False,indent=2)+'\n'
def main():
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');args=p.parse_args();page,index=build()
    if args.check:
        assert OUTPUT.read_text('utf-8')==page and INDEX.read_text('utf-8')==index,'Guide/source index drift; regenerate after reviewing the source change'
        print('UNIFIED_GUIDE_CHECK PASS')
    else:OUTPUT.write_text(page,'utf-8');INDEX.write_text(index,'utf-8');print('UNIFIED_GUIDE_BUILT')
if __name__=='__main__':main()
