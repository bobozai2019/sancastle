"""GodotIQ MCP prompts."""
